import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import {Grid, Row, Col} from 'react-bootstrap';
import {Nav, Navbar, NavItem} from 'react-bootstrap';
import {LinkContainer, IndexLinkContainer} from 'react-router-bootstrap';
import {AutoAffix} from 'react-overlays';
import Waypoint from 'react-waypoint';
import ScrollingProgressBar from './ScrollingProgressBar';

// Import SVG files
var DatabaseSvg = require('babel!svg-react!../assets/images/database.svg?name=database');
var SaveSvg = require('babel!svg-react!../assets/images/save-18.svg?name=save');
var CheckSvg = require('babel!svg-react!../assets/images/check.svg?name=check');
var CloseSvg = require('babel!svg-react!../assets/images/close.svg?name=close');
var ListSvg = require('babel!svg-react!../assets/images/list.svg?name=list');

// Import navigation
var NavList = require('../config/navigation.json');

class ConfigLayout extends Component {

  constructor(props) {
    super(props);

    // Bind functions
    this.handleNavClick = this.handleNavClick.bind(this);
    this.createNavId = this.createNavId.bind(this);
    this.handleSectionSelect = this.handleSectionSelect.bind(this);
    this.renderWaypoint = this.renderWaypoint.bind(this);
    this.handleAffixedTop = this.handleAffixedTop.bind(this);
    this.handleAffixed = this.handleAffixed.bind(this);

    // Set initial state
    this.state = {
      navIndex: 0,
      subNavIndex: 0,
      sectionIndex: 0
    };
  }

  componentDidMount() {
    this.handleAffixedTop();
  }

  // FIXME: What is this used for?
  handleAffixedTop() {
    if (ReactDOM.findDOMNode(this.refs.tButton) && document.getElementsByClassName('navbar-collapse collapse in').length === 0) {
      ReactDOM.findDOMNode(this.refs.tButton).click();
    }

    ReactDOM.findDOMNode(this.refs.dataArea).setAttribute('style', 'margin-top:0');
  }

  // FIXME: What is this used for?
  handleAffixed() {
    if (ReactDOM.findDOMNode(this.refs.tButton) && document.getElementsByClassName('navbar-collapse collapse in').length > 0) {
      ReactDOM.findDOMNode(this.refs.tButton).click();
    }

    ReactDOM.findDOMNode(this.refs.dataArea).setAttribute('style', 'margin-top:300px');
  }

  // Handles the nav click event when the view is changed to update state view indexes
  handleNavClick(navIndex, subNavIndex) {
    // FIXME: Is this needed? If so, should first check if window is not null/undefined
    window.scrollTo(0, 0);
    this.setState({navIndex: navIndex, subNavIndex: subNavIndex, sectionIndex: 0});
  }

  // Updates the sectionIndex state when the section is clicked within the navigation
  // or when the section is scrolled to
  handleSectionSelect(sectionIndex) {
    this.setState({sectionIndex: sectionIndex});
  }

  // Generates the nav id
  createNavId(navIndex, subNavIndex, sectionIndex) {
    return 'nav-' + navIndex + '-' + subNavIndex + '-' + sectionIndex;
  }

  // Renders the title and waypoint breakpoint for the sub menu section
  renderWaypoint(sectionIndex) {
    // FIXME: Ideally should not have to perform the index out of bounds check.
    // Should be removed later once we start building out the actual components
    let sections = NavList[this.state.navIndex].subNav[this.state.subNavIndex].sections;
    var title = sections && sections < sections.length
      ? sections[sectionIndex].name
      : 'Missing Sub Nav Title';

    return (
      <h5 id={this.createNavId(this.state.navIndex, this.state.subNavIndex, sectionIndex)}>
        {title}
        <Waypoint onEnter={() => {
          this.handleSectionSelect(sectionIndex);
        }}/>
      </h5>
    );
  }

  render() {
    // Constants
    const NAV_AFFIX_OFFSET = -120;
    const SIDE_NAV_AFFIX_OFFSET = 50;

    // Add functions to the child props
    var childProps = {
      renderWaypoint: this.renderWaypoint,
      handleSectionSelect: this.handleSectionSelect
    }

    // Clone child elements and add in additional child props
    var childNodes = React.Children.map(this.props.children, (child) => React.cloneElement(child, childProps));

    return (
      <Grid className='config'>
        <Row>
          <AutoAffix affixClassName='affixedTop' viewportOffsetTop={NAV_AFFIX_OFFSET} onAffixed={this.handleAffixed} onAffixedTop={this.handleAffixedTop}>
            <Navbar inverse>
              <Navbar.Header>
                <Navbar.Brand>
                  <CheckSvg className='checkIcon'/>
                  <DatabaseSvg className='databaseIcon'/>
                  <span className='header'>Hotel Configuration</span>
                </Navbar.Brand>
                <Navbar.Brand className='pull-right'>
                  <CloseSvg className='closeIcon'/>
                  <div className='rightHeader'>SAVE</div>
                  <SaveSvg className='saveIcon'/>
                </Navbar.Brand>
                <Navbar.Toggle className='tButton' ref='tButton'>
                  <div>
                    <ListSvg className='svg'/>
                    <div className='centerHeader'>{NavList[this.state.navIndex].name}</div>
                  </div>
                </Navbar.Toggle>
              </Navbar.Header>
              <Navbar.Collapse>
                <Nav activeKey={this.createNavId(this.state.navIndex, 0, 0)}>
                  {NavList.map((nav, navIndex) => {
                    return (
                      <LinkContainer eventKey={this.createNavId(navIndex, 0, 0)} to={{
                        pathname: nav.url
                      }}>
                        <NavItem onClick={() => {
                          this.handleNavClick(navIndex, 0)
                        }} className='nav-view' href='#'>{nav.name}</NavItem>
                      </LinkContainer>
                    );
                  })}
                </Nav>
              </Navbar.Collapse>
              <ScrollingProgressBar scrollId='scroll-body'/>
            </Navbar>
          </AutoAffix>
        </Row>
        <Row >
          <AutoAffix viewportOffsetTop={SIDE_NAV_AFFIX_OFFSET} affixClassName='Affixed-SideMenu'>
            <Col xs={3} md={3} lg={3}>
              <Nav bsStyle='pills' stacked className='sidemenu' activeKey={this.createNavId(this.state.navIndex, this.state.subNavIndex, 0)}>
                {NavList[this.state.navIndex].subNav.map((subNav, subNavIndex) => {
                  return (
                    <NavItem className='sideNav-view' onClick={() => {
                      this.handleNavClick(this.state.navIndex, subNavIndex)
                    }} eventKey={this.createNavId(this.state.navIndex, subNavIndex, 0)}>
                      {subNav.name}
                      <Nav bsStyle='pills' stacked className={this.state.subNavIndex === subNavIndex
                        ? 'subSideMenu'
                        : 'subSideMenu hidden'} activeKey={this.createNavId(this.state.navIndex, this.state.subNavIndex, this.state.sectionIndex)}>
                        {subNav.sections.map((section, sectionIndex) => {
                          return (
                            <NavItem eventKey={this.createNavId(this.state.navIndex, subNavIndex, sectionIndex)} href='#'>
                              {section.name}
                              -
                            </NavItem>
                          );
                        })}
                      </Nav>
                    </NavItem>
                  );
                })}
              </Nav>
              <div>&nbsp;</div>
            </Col>
          </AutoAffix>
          <Col xs={9} md={9} lg={9} id='scroll-body' className='dataArea' ref='dataArea'>
            <div className='margin-top-105'>
              {childNodes}
            </div>
          </Col>
        </Row>
      </Grid>
    )
  }
}

export default ConfigLayout;
