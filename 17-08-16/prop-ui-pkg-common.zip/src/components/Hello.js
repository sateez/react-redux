import React from 'react';

let Hello = React.createClass({

  render() {
    return (
      <div>Hello World!</div>
    );
  }
});

export default Hello;
