import React, {Component, PropTypes} from 'react';
import ReactDOM from 'react-dom';
import {Grid, Row, Col, Nav, NavItem} from 'react-bootstrap';
import navigationList from '../assets/json/navigation.json';
import '../assets/styles/_navigation.scss';
var Back = require('babel!svg-react!../assets/images/back.svg?name=list');
var List = require('babel!svg-react!../assets/images/list.svg?name=list');
 class Navigation extends Component {
  constructor(props) {
    super();
    this.state={
  primaryNav: undefined,
  secondaryNav: undefined
}
    console.log(props);
    this.showSecondaryNav = this.showSecondaryNav.bind(this);
    this.hideNavigation = this.hideNavigation.bind(this);
  }

  componentWillMount() {
    
  }

  componentDidMount() {

  }

  showSecondaryNav(key) {
    this.setState({
      primaryNav:key
    })
  }

  hideNavigation() {
    this.setState({
      primaryNav: undefined
    })
  }

  render() {
    return (
      <Grid>
        <Row >
          <Col  className="navigation" >
            <div className="navigationWrapper" >
              <div className="navigationIconWrapper">
                <img src={'/assets/images/logo.png'} className="navigationIcon" alt="LOGO" />
              </div>
              <div className="navigationRolesWrapper"></div>
              <div className="navigationToggleWrapper" ref="navigationToggle">
                <div className="navigationToggleHeader">
                  <List className="listIcon "/>
                  </div>
                <Nav>
                  {navigationList.navigation.map((primaryListItem) => {
                    return (
                      <div>
                      <NavItem onClick={() => { this.showSecondaryNav(primaryListItem.eventKey) }}className="primaryListItem">{primaryListItem.name}
                       </NavItem> 
                      <Nav className={primaryListItem.eventKey === this.state.primaryNav ? " active" : ""}>
                          <div onClick={this.hideNavigation}>
                            <Back className="backIcon"/>
                            <span className="backBtn">Back </span>
                          </div>
                          {primaryListItem.subNavigation.map((secondaryListItem) => {
                            return (
                              <NavItem className="secondaryListItem">{secondaryListItem.name}</NavItem>
                            )
                          }) }
                        </Nav>
                      </div>
                    )
                  }) }
                </Nav>
              </div>
            </div>
          </Col>
          <Col className="dataArea" >
            <div ></div>
          </Col>
        </Row>
      </Grid>
    )
  }
}
export default Navigation;