import React, {Component, PropTypes} from 'react';
import ReactDOM from 'react-dom';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {AutoAffix} from 'react-overlays';
import findIndex from 'lodash/findIndex';
import {LinkContainer, IndexLinkContainer} from 'react-router-bootstrap';
import ScrollingProgressBar from './ScrollingProgressBar';
import {Grid, Row, Col} from 'react-bootstrap';
import {Nav, Navbar, NavItem} from 'react-bootstrap';

var Database = require('babel!svg-react!../assets/images/database.svg?name=database');
var Save = require('babel!svg-react!../assets/images/save-18.svg?name=save');
var Check = require('babel!svg-react!../assets/images/check.svg?name=check');
var Close = require('babel!svg-react!../assets/images/close.svg?name=close');
var List = require('babel!svg-react!../assets/images/list.svg?name=list');
var NavList = require('../config/navigation.json');

class ConfigLayout extends Component {
  constructor(props) {
    super(props);

    // Bind functions
    this.viewChanged = this.viewChanged.bind(this);
    this.sideViewChanged = this.sideViewChanged.bind(this);
    this.setSubSideMenuItem = this.setSubSideMenuItem.bind(this);
    this.getViewName = this.getViewName.bind(this);
    this.getcurrentIndex = this.getcurrentIndex.bind(this);
    this.viewChanged = this.viewChanged.bind(this);
    this.getNextSideView = this.getNextSideView.bind(this);
    this.getNextSubSideView = this.getNextSubSideView.bind(this);
    this.getEventKey = this.getEventKey.bind(this);
    this.affixtop = this.affixtop.bind(this);
    this.affixed = this.affixed.bind(this);
    this.setSideView = this.setSideView.bind(this);
    this.setSubSideView = this.setSubSideView.bind(this);
    this.test = this.test.bind(this);

    // Set initial state
    this.state = {
      currentView: this.props.currentView,
      currentSideView: this.props.currentSideView,
      currentSubSideView: this.props.currentSubSideView,
      currentViewIndex: this.props.currentViewIndex
    };
  }

  componentDidMount() {
    console.log(this.props);
    this.affixtop();
  }

  getcurrentIndex(viewText) {
    return findIndex(NavList.mainMenu, (view) => {
      return view.name === viewText;
    });
  }

  getEventKey(viewText) {
    var index = this.getcurrentIndex(viewText);
    if (index !== -1) {
      return NavList.mainMenu[index].eventKey;
    }
  }

  getViewName() {
    var key = this.state.currentView;
    var index = findIndex(NavList.mainMenu, (view) => {
      return view.eventKey === key;
    });
    if (index !== -1) {
      return NavList.mainMenu[index].name;
    }
  }

  getNextSideView(viewText) {
    var index = this.getcurrentIndex(viewText);
    return NavList.mainMenu[index].sideMenu[0].eventKey;
  }

  getNextSubSideView(viewText) {
    var index = this.getcurrentIndex(viewText);
    return NavList.mainMenu[index].sideMenu[0].subCategories[0].eventKey;
  }

  affixtop() {
    if (ReactDOM.findDOMNode(this.refs.tButton) && document.getElementsByClassName('navbar-collapse collapse in').length === 0) {
      ReactDOM.findDOMNode(this.refs.tButton).click();
    }

    ReactDOM.findDOMNode(this.refs.dataArea).setAttribute('style', 'margin-top:0');
  }

  affixed() {
    if (ReactDOM.findDOMNode(this.refs.tButton) && document.getElementsByClassName('navbar-collapse collapse in').length > 0) {
      ReactDOM.findDOMNode(this.refs.tButton).click();
    }

    ReactDOM.findDOMNode(this.refs.dataArea).setAttribute('style', 'margin-top:300px');
  }

  setSideView(nav) {
    return (
      <NavItem className="sideNav-view" onClick={() => {
        this.sideViewChanged(nav)
      }} eventKey={nav.eventKey}>{nav.name}
        <Nav bsStyle="pills" stacked className="subSideMenu" activeKey={this.state.currentSubSideView}>
          {nav.subCategories.map((subnav, k) => {
            return this.setSubSideView(nav, subnav);
          })}
        </Nav>

      </NavItem>
    );
  }

  setSubSideView(nav, subnav) {
    return (
      <NavItem className={nav.eventKey === this.state.currentSideView
        ? ""
        : "hidden"} eventKey={subnav.eventKey} onClick={(event) => { this.test(event) } }>{subnav.name}
        -</NavItem>
    );
  }

  viewChanged(event) {
    this.setState({
      currentView: this.getEventKey(event.target.innerText),
      currentSideView: this.getNextSideView(event.target.innerText),
      currentSubSideView: this.getNextSubSideView(event.target.innerText),
      currentViewIndex: this.getcurrentIndex(event.target.innerText)
    });
    //window.scrollTo(0, 0);
  }

  sideViewChanged(nav) {
    //window.scrollTo(0, 0);
    this.setState({currentSideView: nav.eventKey})
    this.setState({currentSubSideView: nav.subCategories[0].eventKey})
  }

  setSubSideMenuItem(subSide) {
    this.setState({currentSubSideView: subSide})
  }

  test(event) {
    console.log(event.target.innerText);
  }  
  render() {
    var propsToChild = {
      setSubSideMenuItem: this.setSubSideMenuItem,
      currentView: this.state.currentView,
      currentSideView: this.state.currentSideView,
      currentSubSideView: this.state.currentSubSideView
    }
    var childNodes = React.Children.map(this.props.children, (child) => React.cloneElement(child, propsToChild));
    const AFFIX_OFFSET = -120;
    return (
      <Grid className="scroll-body config">
        <Row>
          <AutoAffix affixClassName="affixedTop" viewportOffsetTop={AFFIX_OFFSET} onAffixed={this.affixed} onAffixedTop={this.affixtop}>

            <Navbar inverse>
              <Navbar.Header >
                <Navbar.Brand>
                  <Check className="checkIcon"></Check>
                  <Database className="databaseIcon"></Database>
                  <span className="header">Hotel Configuration</span>
                </Navbar.Brand>
                <Navbar.Brand className="pull-right">
                  <Close className="closeIcon"></Close>
                  <div className="rightHeader">SAVE</div>
                  <Save className="saveIcon"></Save>
                </Navbar.Brand>
                <Navbar.Toggle className="tButton" ref="tButton">
                  <div >
                    <List className="svg"/>
                    <div className="centerHeader">{this.getViewName()}
                    </div>
                  </div>
                </Navbar.Toggle>
              </Navbar.Header>
              <Navbar.Collapse >
                <Nav activeKey={this.state.currentView}>
                  {NavList.mainMenu.map((nav, i) => {
                    return (
                      <LinkContainer eventKey={nav.eventKey} to={{
                        pathname: nav.url
                      }}>
                        <NavItem onClick={this.viewChanged} className="nav-view" href="#">{nav.name}</NavItem>
                      </LinkContainer>
                    );
                  })}
                </Nav>

              </Navbar.Collapse>
              <ScrollingProgressBar scrollClass="scroll-body"></ScrollingProgressBar>
            </Navbar>
          </AutoAffix>
        </Row>
        <Row >
          <AutoAffix viewportOffsetTop={50} affixClassName="Affixed-SideMenu">
            <Col xs={3} md={3} lg={3}>
              <Nav bsStyle='pills' stacked className='sidemenu' activeKey={this.state.currentSideView}>
                {NavList.mainMenu[this.state.currentViewIndex].sideMenu.map(this.setSideView)}
              </Nav>
              <div >&nbsp;
              </div>
            </Col>
          </AutoAffix>
          <Col xs={9} md={9} lg={9} className="dataArea" ref="dataArea">
            <div className="margin-top-105 ">
              {childNodes}
            </div>
          </Col>
        </Row>
      </Grid>
    )
  }
}

ConfigLayout.defaultProps = {
  currentView: "mm1",
  currentSideView: "sm1",
  currentSubSideView: "p1",
  currentViewIndex: 0
}

export default ConfigLayout;
