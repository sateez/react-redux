'use strict';

var _interopRequireDefault = require('babel-runtime/helpers/interop-require-default').default;
exports.__esModule = true;

var _Hello2 = require('./components/Hello');
var _Hello3 = _interopRequireDefault(_Hello2);
exports.Hello = _Hello3.default;
exports.MainLayout = _interopRequireDefault(require('./components/MainLayout')).default;
