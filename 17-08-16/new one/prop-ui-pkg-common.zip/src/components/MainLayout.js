import React, {Component, PropTypes} from 'react';
import ReactDOM from 'react-dom';
import {Grid, Row, Col, Nav, NavItem, DropdownButton, MenuItem} from 'react-bootstrap';
import navigationList from '../assets/json/navigation.json';
import '../assets/styles/_main-layout.scss';
var logo = require('../assets/images/logo.png');
var Back = require('babel!svg-react!../assets/images/back.svg?name=list');
var List = require('babel!svg-react!../assets/images/list.svg?name=list');
var Chevdown = require('babel!svg-react!../assets/images/chevron-down.svg?name=list');
class MainLayout extends Component {
  constructor(props) {
    super();
    this.state = {
      primaryNav: undefined,
      secondaryNav: undefined
    }
    console.log(props);
    this.showSecondaryNav = this.showSecondaryNav.bind(this);
    this.hideNavigation = this.hideNavigation.bind(this);
    this.setRolesMenu = this.setRolesMenu.bind(this);
    this.setPrimaryList = this.setPrimaryList.bind(this);
    this.setSecondaryList = this.setSecondaryList.bind(this);
    this.getPrimaryIcon = this.getPrimaryIcon.bind(this);
  }

  componentWillMount() {
  }

  componentDidMount() {

  }

  showSecondaryNav(event, key) {
    // ReactDOM.findDOMNode(this.refs.navigationToggle).classList.toggle('toggled');
    document.getElementsByClassName('navigationToggleWrapper')[0].classList.toggle('toggled');
    this.setState({
      primaryNav: key
    })
  }

  hideNavigation(event) {
    event.stopPropagation();
    document.getElementsByClassName('navigationToggleWrapper')[0].classList.toggle('toggled');
    this.setState({
      primaryNav: undefined
    })
  }

  setRolesMenu(rolesMenuItem) {
    return(
      <MenuItem className={rolesMenuItem.eventKey==="rm0"? "frontDeskItem" : ""}eventKey={rolesMenuItem.eventKey}>{rolesMenuItem.name}</MenuItem>
    )
  }

  setPrimaryList(primaryListItem) {
    return (
      <div  >
        <NavItem className="primaryListItem" href="#">
          <div onClick={() => { this.showSecondaryNav(event, primaryListItem.eventKey) } }>
            <i className={'glyphicon glyphicon-' + primaryListItem.logo + ' primaryListItemIcon'}/>{primaryListItem.name}
          </div>
        </NavItem>
        <Nav  className={primaryListItem.eventKey === this.state.primaryNav ? " active slider-wrapper" : "slider-wrapper"}>
          <div className="backBtnWrapper" onClick={() => { this.hideNavigation(event, primaryListItem.eventKey) } }>
            <Back className="backIcon"/>
            <span className="backBtn">Back </span>
            <i className="selectedIcon glyphicon glyphicon-pencil"></i>
          </div>
          {primaryListItem.subNavigation.map(this.setSecondaryList) }
        </Nav>
      </div>
    )
  }
  setSecondaryList(secondaryListItem) {
    return (
      <NavItem className="secondaryListItem " href="#">{secondaryListItem.name}</NavItem>
    )
  }
  getPrimaryIcon(logo) {
    return "<" + logo + " className='primaryListItemIcon'>";
  }
  render() {
    return (
      <Grid>
        <Row >
          <Col  className="navigation" >
            <div className="navigationWrapper" >
              <div className="navigationIconWrapper">
                <div className="navigationIcon"  />
              </div>
              <div className="navigationRolesWrapper">
                <div className="rolesWrapper">
                  <div className="userName">Laura Sutton</div>
                  <div className="userRole">Front Desk Associate</div>
                </div>
                <div className="rolesMenu">
                  <div className="dropdown-wrapper">
                    <Chevdown className=' tealChevron chevdown colorTeal normalSvg  '/>
                    <DropdownButton bsStyle='default' bsSize="lg"  noCaret title="">
                      <div className="arrow-up"/>
                      {navigationList.rolesMenu.map(this.setRolesMenu) }
                    </DropdownButton>
                  </div>
                </div>
              </div>
              <div className="navigationToggleWrapper" ref="navigationToggle">
                <div className="navigationToggleHeader">
                  <List className="listIcon "/>
                </div>
                <Nav activeKey="this.state.primaryNav">
                  {navigationList.navigation.map(this.setPrimaryList) }
                </Nav>
              </div>
            </div>
          </Col>
          <Col className="dataArea" >
            <div ></div>
          </Col>
        </Row>
      </Grid>
    )
  }
}
export default MainLayout;