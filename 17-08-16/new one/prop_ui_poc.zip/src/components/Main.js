import React from 'react';

let Main = React.createClass({

  render() {
    return (
      <div>Main Test Page</div>
    );
  }
});

export default Main;
