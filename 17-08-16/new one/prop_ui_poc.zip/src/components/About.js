import React from 'react';

let About = React.createClass({

  render() {
    return (
      <div>About Test Page</div>
    );
  }
});

export default About;
