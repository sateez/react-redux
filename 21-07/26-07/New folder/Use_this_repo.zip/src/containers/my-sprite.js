var Sprite = require('../../node_modules/svg-sprite-loader/lib/web/sprite');
module.exports = new Sprite();