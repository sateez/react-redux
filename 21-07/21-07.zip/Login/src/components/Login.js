require('normalize.css/normalize.css');
require('bootstrap-loader');
require('../assets/styles/_login.scss');
var LoginSvg = require('babel!svg-react!../assets/images/login.svg?name=Login');
var UserSvg = require('babel!svg-react!../assets/images/user.svg?name=User');
var LockSvg = require('babel!svg-react!../assets/images/lock.svg?name=Lock');
import React from 'react';
import {
  Button,
  Form,
  FormControl,
  FormGroup,
  Glyphicon,
  InputGroup
} from 'react-bootstrap';

class Login extends React.Component {
  render() {
    return (
      <div className="login">
        <div className="logo-container">
          <img src="/assets/images/logo_WA.png" className="img-responsive"></img>
        </div>
        <Form role="form">
          <FormGroup>
            <InputGroup bsSize="lg">
              <InputGroup.Addon>
                <UserSvg></ UserSvg>
              </InputGroup.Addon>
              <FormControl type="text" placeholder="Username"/>
            </InputGroup>
          </FormGroup>
          <FormGroup>
            <InputGroup bsSize="lg">
              <InputGroup.Addon className="password-addon">
                <LockSvg></ LockSvg>
              </InputGroup.Addon>
              <FormControl type="password" placeholder="Password"/>
            </InputGroup>
          </FormGroup>
          <Button className="signinBtn" bsStyle="primary" bsSize="lg" type="submit" block>
            <LoginSvg className="loginIcon"></ LoginSvg>
            <span>&nbsp;SIGN IN</span>
          </Button>
        </Form>
      </div>
    );
  }
}

Login.defaultProps = {};

export default Login;
