import React from 'react';

let Login = React.createClass({

  render() {
    return (
      <div>Welcome to login</div>
    );
  }
});

export default Login;
