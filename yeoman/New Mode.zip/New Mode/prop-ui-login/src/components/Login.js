require('normalize.css/normalize.css');
require('bootstrap-loader');
require('../assets/styles/_login.scss');

import React from 'react';
import {
  Button,
  Form,
  FormControl,
  FormGroup,
  Glyphicon,
  InputGroup
} from 'react-bootstrap';

class Login extends React.Component {
  render() {
    return (
      <div className="login">
        <div className="logo-container"></div>
        <Form role="form">
          <FormGroup>
            <InputGroup bsSize="lg">
              <InputGroup.Addon>
                <Glyphicon glyph="user"/>
              </InputGroup.Addon>
              <FormControl type="text" placeholder="Username"/>
            </InputGroup>
          </FormGroup>
          <FormGroup>
            <InputGroup bsSize="lg">
              <InputGroup.Addon>
                <Glyphicon glyph="lock"/>
              </InputGroup.Addon>
              <FormControl type="password" placeholder="Password"/>
            </InputGroup>
          </FormGroup>
          <Button bsStyle="primary" bsSize="lg" type="submit" block>
            <Glyphicon glyph="log-in"/>
            &nbsp;SIGN IN
          </Button>
        </Form>
      </div>
    );
  }
}

Login.defaultProps = {};

export default Login;
