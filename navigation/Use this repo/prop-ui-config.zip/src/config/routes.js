import {RouterUtils} from '@prop-ui/common';

const routes = {
  path: '/props/:propCode/config',
  component: require('../containers/App').default,
  childRoutes: [
    {
      path: 'general-setup',
      key: 'General Setup',
      childRoutes: [
        {
          path: 'property-defaults',
          key: 'Property Defaults',
          component: require('../components/general-setup/PropertyDefaults').default,
          sections: ['Preferences', 'Local Info', 'Front Desk', 'Front Desk Notification']
        }, {
          path: 'reservations',
          key: 'Reservations',
          component: require('../components/general-setup/Reservations').default,
          sections: ['Rate Plan Group', 'Group Settings']
        }, {
          path: 'receipt-setup',
          key: 'Receipt Setup',
          component: require('../components/general-setup/ReceiptSetup').default,
          sections: ['Printing Options', 'Official Reports', 'Information Bills', 'Duplicate', 'Printer Settings']
        }, {
          path: 'guest-receipt-messages',
          key: 'Guest Receipt Messages',
          component: require('../components/general-setup/GuestReceiptMessages').default
        }, {
          path: 'request-codes',
          key: 'Request Codes',
          component: require('../components/general-setup/RequestCodes').default
        }, {
          path: 'currency',
          key: 'Currency',
          component: require('../components/general-setup/Currency').default
        }
      ]
    }, {
      path: 'rooms',
      key: 'Rooms',
      childRoutes: [
        {
          path: 'lounge',
          key: 'Lounge',
          component: require('../components/rooms/Lounge').default,
          sections: ['Bill Desk']
        }
      ]
    }, {
      path: 'housekeeping',
      key: 'Housekeeping',
      childRoutes: [
        {
          path: 'maintenance',
          key: 'Maintenance',
          component: require('../components/housekeeping/Maintenance').default,
          sections: ['Service team']
        }
      ]
    }, {
      path: 'posting',
      key: 'Posting',
      childRoutes: [
        {
          path: 'management',
          key: 'Management',
          component: require('../components/posting/Management').default,
          sections: ['Levels']
        }
      ]
    }, {
      path: 'accounts-receivable',
      key: 'Accounts Receivable',
      childRoutes: [
        {
          path: 'accounts',
          key: 'Accounts',
          component: require('../components/accounts-receivable/Accounts').default,
          sections: ['Type of Accounts']
        }
      ]
    }, {
      path: 'reports',
      key: 'Reports',
      childRoutes: [
        {
          path: 'reports',
          key: 'Reports',
          component: require('../components/reports/Reports').default,
          sections: ['Type of Reports']
        }
      ]
    }, {
      path: 'user-setup',
      key: 'User Setup',
      childRoutes: [
        {
          path: 'users',
          key: 'Users',
          component: require('../components/user-setup/Users').default,
          sections: ['Type of Users']
        }
      ]
    }
  ]
};

export default RouterUtils.prepareRoutes(routes, null);
