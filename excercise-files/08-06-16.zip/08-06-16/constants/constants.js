export const DEFAULT_APP_OBJECT = {
      applicationName:"waldorf astoria"
}
