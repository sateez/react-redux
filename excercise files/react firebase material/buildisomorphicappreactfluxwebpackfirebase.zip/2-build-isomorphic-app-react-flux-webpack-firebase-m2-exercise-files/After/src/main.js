import React from 'react';
import App from './components/App.jsx';
require('./main.scss');

React.render(<App />, document.getElementById('container'));
