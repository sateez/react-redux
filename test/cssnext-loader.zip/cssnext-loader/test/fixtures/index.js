var css = require("style-loader!css-loader!../..!./file.css")

module.exports = css
