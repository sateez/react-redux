import React from 'react'

export default React.createClass({
  render() {
    return <div>Rooms</div>
  }
})
