/* CAUTION: When using the generators, this file is modified in some places.
 *          This is done via AST traversal - Some of your formatting may be lost
 *          in the process - no functionality should be broken though.
 *          This modifications only run once when the generator is invoked - if
 *          you edit them, they are not updated again.
 */
import React, {Component, PropTypes} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Nav, Navbar, NavItem, Modal} from 'react-bootstrap';
import {LinkContainer,IndexLinkContainer} from 'react-router-bootstrap';
var Database = require('babel!svg-react!../assets/images/database.svg?name=database');
var Save = require('babel!svg-react!../assets/images/save-18.svg?name=save');
var Check = require('babel!svg-react!../assets/images/check.svg?name=check');
var Close = require('babel!svg-react!../assets/images/close.svg?name=close');
var List = require('babel!svg-react!../assets/images/list.svg?name=list');

var NavList = require('../config/navigation.json');


const ACTIVE = { color: 'red' };
function handleClick(key) {
  console.log(key);
  }
/* Populated by react-webpack-redux:reducer */
class App extends Component {
  constructor(props) {
    super(props);
    this.changeScrollIndicator = _.debounce(this.changeScrollIndicator, 50);
    // Process NavList. Populate the eventKey and the names from the resource bundle
    for (var i = 0; i < NavList.length; i++) {
      var navItem = NavList[i];
      navItem.eventKey = (i + 1);
    }
  }

  componentDidMount() {        
    var icon = $.parseHTML('<img class="svg listIcon" src="/assets/images/list.svg" alt="list here"><span class="centerHeader">General Setup</span>');
    $('button.navbar-toggle').text('').css('border', 'none').prepend(icon);
    window.addEventListener("resize", this.changeScrollIndicator);
    this.changeScrollIndicator();
  }  
  changeScrollIndicator() {   
    var percent = 0;
    var top = $(window).scrollTop();
    var mbodyHeight = $(".scroll-body").height();
    var wrapperHeight = $(".modal-content").height();
    var wraperTop = $(".modal-content").offset().top;
    var mDialogTop = $(".scroll-body").offset().top;
    //  if (window.innerWidth <= 1024) {
    //   setTimeout(function () {
    //     if (mDialogTop > 0 && $('.navbar-collapse.collapse.in').length===0) {
    //       alert("Nav bar list height : "+mDialogTop+", Length : "+$('.navbar-collapse.collapse.in').length);
    //       $('.navbar-toggle').trigger('click');
    //     }
    // }, 100);
    // } 
    //console.log(wraperTop, mDialogTop, mbodyHeight, wrapperHeight);
    var percent = ((wraperTop - mDialogTop - 50) / (mbodyHeight - wrapperHeight)) * 100;
    //alert(mDialogTop);
    if (mDialogTop < -50) {
      $('#scrollIndicator').css({ width: "" + percent + "%", display: 'block' })
      if (window.innerWidth > 1024) {
        $('#scrollIndicator,.navbar-collapse.collapse,.navbar-header,.navbar-nav').addClass('fixedTop');
        $('.navbar-brand .header,.navbar-toggle,.checkIcon').hide();
        $('.databaseIcon').show();
      } else {
        //$('.navbar-collapse.collapse').removeAttr("style").addClass('in').hide();  
        if ($('.navbar-collapse.collapse').css('height') !== "1px") {
          $('.navbar-toggle').trigger('click');
        }
        $('#scrollIndicator').removeClass('fixedTop');
        $('.navbar-brand .checkIcon,.navbar-toggle,.centerHeader').show();
        $('.header,.databaseIcon').hide();
      }
    } else {
      $('#scrollIndicator').css({ width: "0", display: 'none' })
      if (window.innerWidth > 1024) {
        $('#scrollIndicator,.navbar-collapse.collapse,.navbar-header,.navbar-nav').removeClass('fixedTop');
        $('.header,.databaseIcon').show();
      } else {
        //$('.navbar-collapse.collapse').removeClass('in').show();
        setTimeout(function () {
          var navHeight = $('.navbar-collapse.collapse').css('height');
          var isNavbar = $('.navbar-collapse.in').length;
          if ( (isNavbar===0 && navHeight=== "110px") || navHeight === "1px") {
          $('.navbar-toggle').trigger('click');
        }
        $('.navbar-brand .checkIcon,.navbar-toggle,.centerHeader').hide();
        $('.header,.databaseIcon').show();
        }, 100);        
      }

    }
  }
  handleClick(nav) {
    alert(nav)
  }
  
  render() {
    return (
      <Modal  bsStyle="fullscreen" id="fullscreenModal"   show="true" >
        <Modal.Header className="fullscreen  pull-right"></Modal.Header>
        <Navbar inverse fixedTop >
          <Navbar.Header>

            <Navbar.Brand>
              <Check className="checkIcon"></Check>
              <Database className="databaseIcon"></Database>
              <span className="header">Hotel Configuration</span>
            </Navbar.Brand>
            <Navbar.Brand className="pull-right">
              <Close className="closeIcon"></Close>
              <div className="rightHeader">Save</div>
              <Save className="saveIcon"></Save>
            </Navbar.Brand>
            <Navbar.Toggle/>
          </Navbar.Header>
          <Navbar.Collapse>
            <Nav >
              {NavList.map(function (nav) {
                return (
                  <LinkContainer onSelect={handleClick().bind(this)}  to={{
                    pathname: nav.url
                  }}>
                    <NavItem   href="#">{nav.name}</NavItem>
                  </LinkContainer>
                );
              }) }
            </Nav>

          </Navbar.Collapse>
          <div id="scrollIndicator"></div>
        </Navbar>

        <div className="margin-top-105" onScroll={this.changeScrollIndicator.bind(this) }>
          {this.props.children}
        </div>
      </Modal>
    )
  }
}

/* Populated by react-webpack-redux:reducer
 *
 * HINT: if you adjust the initial type of your reducer, you will also have to
 *       adjust it here.
 */
App.propTypes = {
  actions: PropTypes.object.isRequired
};

function mapStateToProps(state) {
  /* Populated by react-webpack-redux:reducer */
  const props = {};
  return props;
}

function mapDispatchToProps(dispatch) {
  /* Populated by react-webpack-redux:action */
  const actions = {};
  const actionMap = {
    actions: bindActionCreators(actions, dispatch)
  };
  return actionMap;
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
