import React from 'react';
import {Grid, Row, Col, Nav, NavItem, ListGroup, ListGroupItem, AutoAffix,
  FormGroup, FormControl, ControlLabel, DropdownButton, MenuItem, Checkbox, Radio} from 'react-bootstrap';
var Chevdown =  require('babel!svg-react!../assets/images/chevron-down.svg?name=Chevdown');


export default React.createClass({
  
  render() {
    return (<Grid className="scroll-body">
    <Row>
      <Col xs={3} md={3} lg={3} >
        <Nav bsStyle="pills" className="affix" data-offset-top="50" stacked>


          <NavItem className="active">
            GENERAL SETUP
           </NavItem>


          <NavItem>
            ROOMS
          </NavItem>


          <NavItem>
            HOUSEKEEPING
          </NavItem>

          <NavItem>
            POSTING
          </NavItem>


          <NavItem>
            REPORTS
          </NavItem>


        </Nav>
        <div>&nbsp;</div>
      </Col>
      <Col xs={9} md={9} lg={9} >
      <div className="main-selection-heading">General Setup</div>
     
 <div className="col-xs-5">
 



 <FormGroup>



 <ControlLabel htmlFor="exampleInputEmail1">
 Hotel Name
 </ControlLabel>
 <FormControl
 type="email"
 id="exampleInputEmail1"
 placeholder="Enter Name" />
 </FormGroup>
 </div>
 <br />
 <div className="clearfix"></div>
 <hr />
 <div>Which is your hotel brand ?</div>
 <div className="dropdown-wrapper">
  <Chevdown  className=' tealChevron chevdown colorTeal normalSvg  '/>
  <DropdownButton bsStyle='default'  noCaret title="default">
       <MenuItem eventKey="1">Option 1</MenuItem>
       <MenuItem eventKey="2">Option 2</MenuItem>
       <MenuItem eventKey="3" active>Option 3</MenuItem>
       <MenuItem eventKey="4">Option 4</MenuItem>
     </DropdownButton>
 </div>
 <br />
  <hr /> 
   <div className="col-xs-2 sub-selection-heading">Preferences</div>
 <br />
 <div className="clearfix"></div>
 <hr />
<div>
<div>Would you like to require any of the following at guest check in ?</div>

<div className="pull-left">
 <Checkbox defaultChecked >
 <span className="cr">
 <i className="cr-icon glyphicon glyphicon-ok"></i>
 </span>
 Yes
 </Checkbox>
 </div>
 <div className="pull-left">
 <Checkbox defaultChecked >
 <span className="cr">
 <i className="cr-icon glyphicon glyphicon-ok"></i>
 </span>
 Yes
 </Checkbox>
 </div>
 <div className="pull-left">
 <Checkbox defaultChecked >
 <span className="cr">
 <i className="cr-icon glyphicon glyphicon-ok"></i>
 </span>
 Yes
 </Checkbox>
 </div>
 <div className="pull-left">
 <Checkbox defaultChecked >
 <span className="cr">
 <i className="cr-icon glyphicon glyphicon-ok"></i>
 </span>
 Yes
 </Checkbox>
 </div>
 </div>
 <div className="clearfix"></div>
 <br />
 <hr />

 <div className="col-sm-12">
<div>What is your property ownership ?</div>

 <FormGroup>

 <Radio name="testradio" >
 <span className="cr">
 <i className="cr-icon fa fa-circle"></i>
 </span>
 <label>
 Yes
 </label>
 </Radio>
 <Radio defaultChecked name="testradio">
 <span className="cr">
 <i className="cr-icon fa fa-circle"></i>
 </span>
 <label>
 No
 </label>
  </Radio>
 </FormGroup>
 </div>

 <br />
        <h4>Overflowing text to show scroll behavior</h4>       
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>
        <p>Cras mattis consectetur purus sit amet fermentum.Cras justo odio, dapibus ac facilisis in, egestas eget quam.Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
        <p>Aenean lacinia bibendum nulla sed consectetur.Praesent commodo cursus magna, vel scelerisque nisl consectetur et.Donec sed odio dui.Donec ullamcorper nulla non metus auctor fringilla.</p>

      </Col>
      </Row>
    </Grid>)
  }
})
