import React from 'react'

export default React.createClass({
  render() {
    return <div>House Keeping</div>
  }
})
