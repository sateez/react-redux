import RouterUtils from '../lib/router-utils';
console.log(RouterUtils);
const routes = {
  path: '/props/:propCode/poc',
  component: require('../components/MainLayout').default,
  childRoutes: [
    {
      path: 'main',
      key: 'Main',
      logo:'pencil',
      childRoutes: [
        {
          path: 'main-1',
          key: 'main 1',
          component: '',
          sections: []
        }, {
          path: 'main-2',
          key: 'Main 2',
          component: '',
          sections: []
        }
      ]
      },  
    {
      path: 'about',
      key: 'About',
      'logo':'envelope',
      childRoutes: [
        {
          path: 'about-1',
          key: 'About 1',
          component: '',
          sections: []
        }, {
          path: 'about-2',
          key: 'About 2',
          component: '',
          sections: []
        }
      ]
    },  
  ]
};

export default RouterUtils.prepareRoutes(routes, null);
