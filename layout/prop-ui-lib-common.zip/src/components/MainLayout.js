import React, {Component, PropTypes} from 'react';
import ReactDOM from 'react-dom';
import {Grid, Row, Col, Nav, NavItem, DropdownButton, MenuItem} from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap';
import navigationList from '../assets/json/navigation.json';
import '../assets/styles/_main-layout.scss';
import routes from '../config/routes';
import RouterUtils from '../lib/router-utils';
var logo = require('../assets/images/logo.png');
var Back = require('babel!svg-react!../assets/images/back.svg?name=list');
var List = require('babel!svg-react!../assets/images/list.svg?name=list');
var Chevdown = require('babel!svg-react!../assets/images/chevron-down.svg?name=list');
class MainLayout extends Component {
  constructor(props) {
    super();
    this.state = {
      primaryListItem: undefined,
      secondaryListItem: undefined
    }
    this.handlePrimaryNav = this.handlePrimaryNav.bind(this);
    this.handleSecondaryNav = this.handleSecondaryNav.bind(this);
    this.createNavId = this.createNavId.bind(this);
    this.handleRolesMenu = this.handleRolesMenu.bind(this);
    this.handlePrimaryList = this.handlePrimaryList.bind(this);
    this.handleSecondaryList = this.handleSecondaryList.bind(this);
  }

  // on click of primary navigation item it shows the secondary navigation menu
  handlePrimaryNav(event, key) {
    event.stopPropagation();
    this.setState({
      primaryListItem: key
    })
  }
  // on click of primary navigation item it shows the secondary navigation menu
  handleSecondaryNav(event, key) {
    event.stopPropagation();
    this.setState({
      primaryListItem: key
    })
  }
// Generates the nav id
  createNavId(primaryListItem, secondaryListItem) {
    return 'layout-' + primaryListItem + '-' + secondaryListItem;
  }
  // function to render the dropdown menu in roles section  
  handleRolesMenu(rolesMenuItem) {
    return (
      <MenuItem className={rolesMenuItem.eventKey === 'rm0' ? 'frontDeskItem' : ''}eventKey={rolesMenuItem.eventKey}>{rolesMenuItem.name}</MenuItem>
    )
  }

  //function to render the primary and secondary navigation menus
       // <LinkContainer key={this.createNavId(index,0)} eventKey={this.createNavId(index,0)} to={RouterUtils.formatURL(primaryListItem.url, this.props.routeParams)}>
         // </LinkContainer>
  handlePrimaryList(primaryListItem, index) {
    console.log(primaryListItem, index);
    return (
      <div >
                    
        <NavItem className='primaryListItem' href='#'>
          <div onClick={() => { this.handlePrimaryNav(event, index) } }>
            <i className={'glyphicon glyphicon-' + primaryListItem.logo + ' primaryListItemIcon'}/>{primaryListItem.key}
          </div>
        </NavItem>
        <Nav  className={index === this.state.primaryListItem ? ' active slider-wrapper' : 'slider-wrapper'}>
          <div className='backBtnWrapper' onClick={() => { this.handlePrimaryNav(event, undefined) } }>
            <Back className='backIcon'/>
            <span className='backBtn'>Back </span>
            <i className={'selectedIcon glyphicon glyphicon-' + primaryListItem.logo}></i>
          </div>
          {primaryListItem.childRoutes.map(this.handleSecondaryList) }
        </Nav>
      </div>
    )
  }

  //function to render the  secondary navigation menu items
  handleSecondaryList(secondaryListItem, index) {
    console.log(secondaryListItem, index);
    return (
      <LinkContainer key={this.createNavId(this.state.primaryListItem, index)} eventKey={this.createNavId(this.state.primaryListItem, index)} to={RouterUtils.formatURL(secondaryListItem.url, this.props.routeParams)}>
        
        <NavItem className='secondaryListItem ' >{secondaryListItem.key}</NavItem>
      </LinkContainer>  
    )
  }

  //method that renders the entire main layout component
  render() {
    return (
      <Grid>
        <Row >
          <Col  className='navigation' >
            <div className='navigationWrapper' >
              <div className='navigationIconWrapper'>
                <div className='navigationIcon'  />
              </div>
              <div className='navigationRolesWrapper'>
                <div className='rolesWrapper'>
                  <div className='userName'>Laura Sutton</div>
                  <div className='userRole'>Front Desk Associate</div>
                </div>
                <div className='rolesMenu'>
                  <div className='dropdown-wrapper'>
                    <Chevdown className=' tealChevron chevdown colorTeal normalSvg  '/>
                    <DropdownButton bsStyle='default' bsSize='lg'  noCaret title=''>
                      <div className='arrow-up'/>
                      {navigationList.rolesMenu.map(this.handleRolesMenu) }
                    </DropdownButton>
                  </div>
                </div>
              </div>
              <div className={(this.state.primaryListItem !== undefined) ?'navigationToggleWrapper toggledSecondaryNavigation':'navigationToggleWrapper'}>
                <div className='navigationToggleHeader'>
                  <List className='listIcon '/>
                </div>
                <Nav activeKey='this.state.primaryNav'>
                  {routes.childRoutes.map(this.handlePrimaryList) }
                </Nav>
              </div>
            </div>
          </Col>
          <Col className='dataArea' >
            <div ></div>
          </Col>
        </Row>
      </Grid>
    )
  }
}
export default MainLayout;
