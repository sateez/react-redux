# @prop-ui/common [![NPM version][npm-image]][npm-url] [![Build Status][travis-image]][travis-url] [![Dependency Status][daviddm-image]][daviddm-url]
> Prop UI common package

## Installation

```sh
$ npm install --save @prop-ui/common
```

## Usage

```js
var propUiCommon = require('@prop-ui/common');

propUiCommon('Rainbow');
```
## License

Apache-2.0 © [Hisham Ali]()


[npm-image]: https://badge.fury.io/js/@prop-ui-pkj/common.svg
[npm-url]: https://npmjs.org/package/@prop-ui-pkj/common
[travis-image]: https://travis-ci.org//@prop-ui-pkj/common.svg?branch=master
[travis-url]: https://travis-ci.org//@prop-ui-pkj/common
[daviddm-image]: https://david-dm.org//@prop-ui-pkj/common.svg?theme=shields.io
[daviddm-url]: https://david-dm.org//@prop-ui-pkj/common
