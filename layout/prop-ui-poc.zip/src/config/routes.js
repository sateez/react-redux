import {RouterUtils} from '@prop-ui/common';

const routes = {
  path: '/props/:propCode/poc',
  component: require('../containers/App').default,
  childRoutes: [
    {
      path: 'main',
      key: 'main',
      component: require('../components/Main').default
    }, {
      path: 'about',
      key: 'about',
      component: require('../components/About').default
    }
  ]
};

export default RouterUtils.prepareRoutes(routes, null);
