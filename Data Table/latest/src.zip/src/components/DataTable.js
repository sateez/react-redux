import React, {Component, PropTypes} from 'react'
import ReactDataGrid from 'react-data-grid';
import {Toolbar, Data, Filters, Selectors} from 'react-data-grid/addons';
var classNames = require('classnames');

class DataTable extends Component {

  constructor(props) {
    super(props);

    // Bind functions
    this.getRow = this.getRow.bind(this);
    this.handleGridSort = this.handleGridSort.bind(this);
    this.handleRowsSelected = this.handleRowsSelected.bind(this);
    this.handleRowsDeselected = this.handleRowsDeselected.bind(this);
    this.handleAllColumnFilterChange = this.handleAllColumnFilterChange.bind(this);
    this.handleColumnFilterChange = this.handleColumnFilterChange.bind(this);
    this.doColumnFilterChange = this.doColumnFilterChange.bind(this);
    this.handleClearColumnFilter = this.handleClearColumnFilter.bind(this);
    this.renderFilterToolbar = this.renderFilterToolbar.bind(this);
    this.handleRowClick = this.handleRowClick.bind(this);
    this.handleRowsDragDrop = this.handleRowsDragDrop.bind(this);
    this.handleDraggedRowSelected = this.handleDraggedRowSelected.bind(this);
    this.handleRowUpdated = this.handleRowUpdated.bind(this);
    this.renderRowRenderer = this.renderRowRenderer.bind(this);

    // Set initial state
    this.state = {
      columns: props.columns,
      rows: props.rows,
      filters: {},
      allColumnFilterTerm: null,
      sortColumn: null,
      sortDirection: null,
      selectedIndexes: []
    }
  }

  // Returns all rows to be displayed (filtered list of rows if a filter criteria is provided)
  getRows() {
    return Data.Selectors.getRows(this.state);
  }

  // Returns size of all rows displayed (filtered list of rows if a filter criteria is provided)
  getSize() {
    return this.getRows().length;
  }

  // Returns row based on index provided within the lit of all rows displayed
  // (filtered list of rows if a filter criteria is provided)
  getRow(index) {
    var rows = this.getRows();
    return rows[index];
  }

  // Sorts the given column based on the direction provided. This function is called
  // on click of column header cells
  handleGridSort (sortColumn, sortDirection){

    var comparer = function(a, b) {
      if(sortDirection === 'ASC'){
        return (a[sortColumn] > b[sortColumn]) ? 1 : -1;
      }else if(sortDirection === 'DESC'){
        return (a[sortColumn] < b[sortColumn]) ? 1 : -1;
      }
    }
    var rows = sortDirection === 'NONE' ? this.state.originalRows.slice(0) : this.state.rows.sort(comparer);
    this.setState({rows : rows});
  }

  // Filters all of the columns in the grid based upon given input box above
  handleAllColumnFilterChange(event) {
    this.doColumnFilterChange(null, event.target.value)
  }

  // Filters columns in the grid based upon type of filter passed to this funcion
  handleColumnFilterChange(colFilter) {
    this.doColumnFilterChange(colFilter, this.state.allColumnFilterTerm)
  }

  // Generates the filter configurations and updates the state
  doColumnFilterChange(colFilter, allColumnFilterTerm) {
    let self = this
    let newFilters = Object.assign({}, this.state.filters)
    let allColumnFilterValues = null

    // Update filters if a column filter term is provided
    if (colFilter) {
      newFilters[colFilter.column.key] = colFilter
    }

    // If an all column filter term is provided, define a filterValues function that checks all
    // the column values in the row for a match on the filter term
    if (allColumnFilterTerm && allColumnFilterTerm.trim().length >= 0) {
      allColumnFilterValues = function(row, colFilter, columnKey) {
        for (let column of self.props.columns) {
          if (column.filterable) {
            let rowValue = row[column.key]
            if (rowValue && rowValue.toString().toLowerCase().indexOf(allColumnFilterTerm.toLowerCase()) >= 0) {
              return true
            }
          }
        }
        return false
      }
    }

    for (let column of this.props.columns) {
      let newColFilter = newFilters[column.key]

      // Create the column filter if it does not already exist
      if (!newColFilter) {
        newColFilter = {
          column: column
        }
      }

      // If an all column filter term is provided and the column filter doesn't contain a filter term,
      // then set the filterValues function value
      if (allColumnFilterValues && !newColFilter.filterTerm) {
        newColFilter.filterValues = allColumnFilterValues
      }

      // Add the column filter from the new list of column filters if it either has a filter term or a filterValues function,
      // otherwise remove the column filter.
      if (column.filterable && (newColFilter.filterTerm || newColFilter.filterValues)) {
        newFilters[column.key] = newColFilter
      } else {
        delete newFilters[column.key]
      }
    }

    this.setState({filters: newFilters, allColumnFilterTerm: allColumnFilterTerm})
  }

  // Clears the column filters
  handleClearColumnFilter() {
    this.setState({filters: {}})
  }

  // On selection of particular row it get's all the indexes of selected and updates the state
  handleRowsSelected(rows) {
    this.setState({
      selectedIndexes: this.state.selectedIndexes.concat(rows.map(r => r.row.code))
    });
  }

  // On deselection of particular row it filters indexe of selected and updates the state
  handleRowsDeselected(rows) {
    var rowIndexes = rows.map(r => r.row.code);
    this.setState({
      selectedIndexes: this.state.selectedIndexes.filter(i => rowIndexes.indexOf(i) === -1)
    });
  }

  

  // On click of row this method triggers to add or remove the selected row index from selected Indexes
  handleRowClick(rowIdx, row) {
    var objArrParam = [
      {
        row: row,
        rowIdx: rowIdx
      }
    ];
    if (this.state.selectedIndexes.indexOf(rowIdx) === -1) {
      this.handleRowsSelected(objArrParam);
    } else {
      this.handleRowsDeselected(objArrParam);
    }
  }

  // this function is triggered when we select row/rows dragged and dropped in any other location
  handleRowsDragDrop(e) {
    var Selectors = ReactDataGridPlugins.Data.Selectors;
    let selectedRows = Selectors.getSelectedRowsByKey({rowKey: this.props.rowKey, selectedKeys: this.state.selectedIndexes, rows: this.state.rows});
    let draggedRows = this.handleDraggedRowSelected(selectedRows, e.rowSource)
      ? selectedRows
      : [e.rowSource.data];
    let undraggedRows = this.state.rows.filter(function(r) {
      return draggedRows.indexOf(r) === -1;
    });
    var args = [e.rowTarget.idx, 0].concat(draggedRows);
    Array.prototype.splice.apply(undraggedRows, args);
    setTimeout(() => {
      this.setState({rows: undraggedRows});
    }, 100)
  }

  // On Drag, this function checks if the drag row is selected or not.
  handleDraggedRowSelected(selectedRows, rowDragSource) {
    if (selectedRows && selectedRows.length > 0) {
      let key = this.props.rowKey;
      return selectedRows.filter(function(r) {
        return r[key] === rowDragSource.data[key];
      }).length > 0;
    }
    return false;
  }

  // merge updated row with current row and rerender by setting state
  handleRowUpdated(e) {
    var rows = this.state.rows;
    Object.assign(rows[e.rowIdx], e.updated);
    this.setState({rows: rows});
  }

  // Renders the toolbar component
  renderFilterToolbar() {
    return (<Toolbar enableFilter={true}/>)
  }

  // Custom row renderer to render the rows on drag and drop of the selected rows when isRowDraggable is enabled
  renderRowRenderer() {
    var DropTargetRowContainer = ReactDataGridPlugins.Draggable.DropTargetRowContainer;
    let Renderer = DropTargetRowContainer(ReactDataGrid.Row);
    return (<Renderer onRowDrop={this.handleRowsDragDrop}/>)
  }

  render() {
    var allFilterInputClassName = classNames({'hidden': !this.props.isAllFilterable });
    var draggableContainerClassName = classNames({'hidden': !this.props.isRowDraggable});
    var DraggableContainer = ReactDataGridPlugins.Draggable.Container;

    // Default data grid properties
    var gridProps = {
      columns: this.state.columns,
      rowGetter: this.getRow,
      minHeight: this.props.minHeight,
      rowsCount: this.getSize()
    }

    // This configuration is enabled when isInlineEditable is enabled from props provided to the component
    if (this.props.isInlineEditable) {
      gridProps.onRowSelect = this.onRowSelect;
      gridProps.enableCellSelect = true;
      gridProps.onCellSelected = this.handleRowsSelected
      gridProps.onCellDeSelected = this.handleRowsDeselected;
    }

    // This configuration is enabled when isRowDraggable is enabled from props provided to the component
    if (this.props.isRowDraggable) {
      gridProps.onGridSort = this.handleGridSort;
      gridProps.rowActionsCell = ReactDataGridPlugins.Draggable.RowActionsCell;
      gridProps.onRowUpdated = this.handleRowUpdated;
      gridProps.rowRenderer = this.renderRowRenderer();
    }

    // This configuration is enabled when isRowDraggable or isRowSelectable is enabled from props provided to the component
    if (this.props.isRowSelectable || this.props.isRowDraggable) {
      gridProps.rowSelection = {
        showCheckbox: true,
        enableShiftSelect: true,
        handleRowsSelected: this.handleRowsSelected,
        handleRowsDeselected: this.handleRowsDeselected,
        selectBy: {
          keys: {
            rowKey: this.props.rowKey,
            values: this.state.selectedIndexes
          }
        }
      }
    }

    // This configuration is enabled when isFilterable is enabled from props provided to the component
    if (this.props.isFilterable) {
      gridProps.toolbar = this.renderFilterToolbar();
      gridProps.onAddFilter = this.handleColumnFilterChange;
      gridProps.onClearFilters = this.handleClearColumnFilter;
      gridProps.enableCellSelect = true;
      gridProps.getValidFilterValues = this.getValidFilterValues;
    }

    return (
      <div className='grid-container'>
        {this.props.header}
        <div className='grid-area'>
          <div>
            <input type="text" className={allFilterInputClassName} onChange={this.handleAllColumnFilterChange}/>
            <DraggableContainer className={draggableContainerClassName}>
              <ReactDataGrid {...gridProps}/>
            </DraggableContainer>
          </div>
        </div>
        {this.props.footer}
      </div>
    );
  }
}

DataTable.PropTypes = {
  columns: PropTypes.object.isRequired,
  rows: PropTypes.object.isRequired,
  minHeight: PropTypes.number.isRequired,
  isFilterable: PropTypes.bool,
  isAllFilterable: PropTypes.bool,
  isRowSelectable: PropTypes.bool,
  isRowDraggable: PropTypes.bool,
  isInlineEditable: PropTypes.bool,
  rowKey: PropTypes.string,
  header:PropTypes.element,
  footer:PropTypes.element
}

DataTable.defaultProps = {
  'rowKey': 'code'
}

export default DataTable;
