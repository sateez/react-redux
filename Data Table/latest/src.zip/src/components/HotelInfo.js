import React, {Component, PropTypes} from 'react';
import {Panel, Table} from 'react-bootstrap';
import {translate, Interpolate} from 'react-i18next';
import {connect} from 'react-redux';
import rest from '../actions/rest';

class HotelInfo extends Component {

  componentDidMount() {
    const {dispatch, params} = this.props;
    // fetch property info
    dispatch(rest.actions.prop(params));
  }

  render() {
    const {t, prop, params} = this.props;

    if (prop.loading || !prop.sync) {
      return (
        <div>
          Loading hotel {params.propCode}: {prop.loading}<br/>
        </div>
      );
    } else {
      var hotel = prop.data;
      var header = (<Interpolate i18nKey='hotelInfoTitle' propCode={params.propCode}/>);
      return (
        <Panel header={header} bsStyle='success'>
          <Table responsive striped condensed>
            <tbody>
              <tr>
                <td>ctyhocn</td>
                <td>{hotel.ctyhocn}</td>
              </tr>
            </tbody>
          </Table>
        </Panel>
      );
    }
  }
}

HotelInfo.propTypes = {
  prop: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
}

function mapStateToProps(state) {
  return {prop: state.prop};
}

export default connect(mapStateToProps)(translate()(HotelInfo));
