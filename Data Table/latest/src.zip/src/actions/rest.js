import 'isomorphic-fetch';
import reduxApi from 'redux-api';
import adapterFetch from 'redux-api/lib/adapters/fetch';

// Import env specific configurations
const config = require('config').default;

const rest = reduxApi({
  prop: {
    url: `${config.propsApi}/:propCode`,
    options: function() {
      return {
        headers: {
          'Accept': 'application/json',
          'Accept-Language': 'en-US'
        }
      };
    }
  }
});

// Define the rest adapter to user
rest.use('fetch', adapterFetch(fetch));

export default rest;
