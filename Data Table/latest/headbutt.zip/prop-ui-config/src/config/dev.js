'use strict';

import baseConfig from './base';

let config = {
  appEnv: 'dev',
  propConfigApi: 'https://propconfig.test.hiltonapi.com/props/config',
  propsApi: 'http://localhost:9000/props',
  propsConfigApi: 'https://propconfig.test.hiltonapi.com/props/:propCode/config'
};

export default Object.freeze(Object.assign({}, baseConfig, config));
