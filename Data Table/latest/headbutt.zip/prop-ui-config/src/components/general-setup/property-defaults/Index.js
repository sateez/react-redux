import React, {Component, PropTypes} from 'react';
import {translate} from 'react-i18next';
import {connect} from 'react-redux';
import rest from 'actions/rest';
import HotelInformation from './HotelInformation';

class Index extends Component {

  constructor(props) {
    super(props);
  }

  componentDidMount() {
    const {dispatch, params} = this.props;
    // fetch property info
    dispatch(rest.actions.prop(params));
    // Reset the sectionIndex after the component is rendered
    this.props.handleSectionSelect(0);
  }

  render() {
    let sectionIndex = 0;
    let props = this.props;

    return (
      <div>
        <HotelInformation prop={props.prop}/>
      </div>
    )
  }
}

Index.propTypes = {
  prop: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
}

function mapStateToProps(state) {
  return {prop: state.prop};
}

export default connect(mapStateToProps)(translate()(Index));
